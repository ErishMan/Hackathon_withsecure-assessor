#!/usr/bin/env python3
"""Import full WithSecure dataset and infer categories."""
import csv
from pathlib import Path
from io import StringIO

# Category inference mapping
CATEGORY_MAPPING = {
    "7-zip": "File archiver",
    "peazip": "File archiver",
    "winrar": "File archiver",
    "bandizip": "File archiver",
    "1password": "Password Manager",
    "lastpass": "Password Manager",
    "keepass": "Password Manager",
    "dashlane": "Password Manager",
    "bitwarden": "Password Manager",
    "teamviewer": "Remote Desktop",
    "anydesk": "Remote Desktop",
    "ammyy": "Remote Desktop",
    "tightvnc": "Remote Desktop",
    "ultravnc": "Remote Desktop",
    "supremo": "Remote Desktop",
    "zoom": "Video Conferencing",
    "skype": "Video Conferencing",
    "slack": "Team Collaboration",
    "discord": "Team Collaboration",
    "filezilla": "File Transfer",
    "winscp": "File Transfer",
    "transmit": "File Transfer",
    "veracrypt": "Encryption",
    "axcrypt": "Encryption",
    "cryptomator": "Encryption",
    "bitlocker": "Encryption",
    "malwarebytes": "Security Software",
    "hitmanpro": "Security Software",
    "adwcleaner": "Security Software",
    "superantispyware": "Security Software",
    "ccleaner": "System Utility",
    "bleachbit": "System Utility",
    "iobit": "System Utility",
    "wise disk cleaner": "System Utility",
    "speccy": "System Utility",
    "insomnia": "API Development",
    "postman": "API Development",
    "httpie": "API Development",
    "virtualbox": "Virtualization",
    "qemu": "Virtualization",
    "obs": "Video Recording",
    "camtasia": "Screen Recorder",
    "snagit": "Screen Recorder",
    "movavi screen recorder": "Screen Recorder",
    "audacity": "Audio Editor",
    "handbrake": "Video Converter",
    "movavi video converter": "Video Converter",
    "zotero": "Reference Manager",
    "citavi": "Reference Manager",
    "atom": "Code Editor",
    "ultraedit": "Code Editor",
    "paint.net": "Graphics Editor",
    "inkscape": "Graphics Editor",
    "picpick": "Screen Capture",
    "sharex": "Screen Capture",
    "lightshot": "Screen Capture",
    "faststone capture": "Screen Capture",
    "origin": "Gaming Platform",
    "ubisoft connect": "Gaming Platform",
    "gog galaxy": "Gaming Platform",
    "unreal engine": "Game Engine",
    "godot": "Game Engine",
    "dropbox": "File Sharing",
    "onedrive": "File Sharing",
    "everything": "File Search",
    "foxit reader": "PDF Reader",
    "mobaxterm": "Terminal",
    "termius": "Terminal",
    "zoc terminal": "Terminal",
    "securecrt": "Terminal",
}

KNOWN_HOMEPAGES = {
    "7-zip": "https://www.7-zip.org/",
    "peazip": "https://peazip.github.io/",
    "1password": "https://1password.com/",
    "lastpass": "https://www.lastpass.com/",
    "keepass": "https://keepass.info/",
    "teamviewer": "https://www.teamviewer.com/",
    "anydesk": "https://anydesk.com/",
    "zoom": "https://zoom.us/",
    "slack": "https://slack.com/",
    "discord": "https://discord.com/",
    "filezilla": "https://filezilla-project.org/",
    "winscp": "https://winscp.net/",
    "veracrypt": "https://veracrypt.fr/",
    "cryptomator": "https://cryptomator.org/",
    "malwarebytes": "https://www.malwarebytes.com/",
    "ccleaner": "https://www.ccleaner.com/",
    "bleachbit": "https://www.bleachbit.org/",
    "postman": "https://www.postman.com/",
    "httpie": "https://httpie.io/",
    "virtualbox": "https://www.virtualbox.org/",
    "qemu": "https://www.qemu.org/",
    "obs": "https://obsproject.com/",
    "audacity": "https://www.audacityteam.org/",
    "handbrake": "https://handbrake.fr/",
    "zotero": "https://www.zotero.org/",
    "inkscape": "https://inkscape.org/",
    "sharex": "https://getsharex.com/",
    "dropbox": "https://www.dropbox.com/",
    "everything": "https://www.voidtools.com/",
    "godot": "https://godotengine.org/",
    "termius": "https://termius.com/",
    "mobaxterm": "https://mobaxterm.mobatek.net/",
    "tor browser": "https://www.torproject.org/",
}


def infer_category(product: str, company: str) -> str:
    """Infer product category from name"""
    product_lower = product.lower().strip()
    company_lower = company.lower().strip()
    
    # Direct lookup
    if product_lower in CATEGORY_MAPPING:
        return CATEGORY_MAPPING[product_lower]
    
    # Partial match
    for key, category in CATEGORY_MAPPING.items():
        if key in product_lower or key in company_lower:
            return category
    
    return "Unknown"


def infer_homepage(company: str, product: str) -> str:
    """Infer homepage URL from product/vendor name"""
    product_lower = product.lower().strip()
    
    # Direct lookup
    if product_lower in KNOWN_HOMEPAGES:
        return KNOWN_HOMEPAGES[product_lower]
    
    # Partial match
    for key, homepage in KNOWN_HOMEPAGES.items():
        if key in product_lower:
            return homepage
    
    return "https://example.com/"


# Read source CSV (from challenge) - FIXED to handle quoted fields
source_csv = """company_name,product_name,sha1
Giorgio Tani,PeaZip,bcd9fd198cab024450c1f2d09d83aeeeee6a2a4a
Igor Pavlov,7-Zip,ff22e3a12e153e70014179f83f85459f8db1191c
Tim Kosse,FileZilla,e94803128b6368b5c2c876a782b1e88346356844
1Password,1Password,e5ee385388b5fa57cc8374102d779d3c9849a57f
"GoTo Group, Inc.",LastPass,fa946b6d4293b0a0bae0e94ffcd6817f4526aa3b
NirSoft,SearchMyFiles,77cfb3b4dc28e47ddba222982e6b6cd1c935e127
Kong,Insomnia,fd9b8a6a2e3045d250efa0400bb636d3e634681f
EmTec Innovative Software,ZOC Terminal,51dac5be22e93772d40dfa47ca25408886626f5d
Stas'M Corp.,RDP Host Support,66f40824b406c748846ef11e6b022958f8cbe48b
https://www.qemu.org,QEMU,c9ec956ae1aafabf1437cab16db14c61534b3e14
Rocket Software B.V.,Uniface,f2b74524ebdfdaa9091cba029e67e5d39f7c9711
æ ªå¼ä¼šç¤¾ãƒ¢ãƒ¼ãƒªãƒ³,ç­†ã¾ã‚,49ab845fe16b5ef683facbb6bdc5a015e041552f
AnyDesk Software GmbH,AnyDesk,ff793f21612ac66244f2a41d3102f04f38fe7ded
PlariumPlay,PlariumPlay,fc28c06f316f719a623edbbf21cfa9e30b561929
Slack Technologies Inc.,Slack,f53f36c766c615f665dd00de30dc12d2ed4195b9
Progress Software Corporation,Fiddler,a3f06260e08e0df5460892f23938882110ba0106
Foxit Software Company,Foxit Reader,4d0e8ca43856eaf5c2356dfdb076d0f1d7a17a36
Movavi,Movavi Screen Recorder,ca97be01f1df3d9551a4492e19c7ea04340dafe3
Skype Technologies S.A.,Skype,ff816df2a3dc42904b504a77140005ff5af86ea4
Inkscape project,Inkscape,fded59b1e945cc560d48d2f905c3395d8641f74a
Foxit Software Inc.,Foxit Reader,f93916a7b6bf0f562c805a1a98b4dcd5aa5d017a
EJIE Technology,Clover,6ebcc373e30a979582b4c7c6f1c2e50a8039bc33
OneStart.ai,OneStart,37121618e735ebf628f7ba6ce29afc251ed88503
SUPERAntiSpyware,SUPERAntiSpyware,4a996bc861a9f9daa7afe5b834b82b2d573ce184
"Zoom Video Communications, Inc.",Zoom,fd797e4071afe131104c1d29cd0cb606da62f3d5
Bandisoft International Inc.,Bandizip,ccdeec743af30d6ee512996963f87e085d181ad7
Godot Engine,Godot Engine,727f49ce2b4c34ecd88554f7c8ab6f0f746f8bbb
TechSmith Corporation,Camtasia,843b008a36f319d523c3cc45cee034c05f1c7e3d
Iain Patterson,NSSM,47c112c23c7bdf2af24a20bd512f91ff6af76bc6
"Fuji Xerox Co., Ltd.",DocuWorks,f6e383660df4dd2ab8a8d437a343e4b54b48f726
Pleasant Solutions,KeePass,83c2bc8ae83509d260e4e166b564873ca358c18c
"Lumivero, LLC",Citavi,7b7c3fb85ef95c7464a8126ee399c0d860c8c9cd
Kakao,PotPlayer,e7dc1366b69b3a737a5ecea3dbb28537bdd078a5
"Dashlane, Inc.",Dashlane,440538893999e2390385c144fa5c2e6e8ec73ba8
EPI Software,EpiBrowser,ee7f1074f1345b2543a91192214f99d7d9ad7e69
Piriform Software Ltd,Speccy,dc566cc0f653a27436ef32b1410e0d1109371d09
2345ç§»åŠ¨ç§'æŠ€,2345çœ‹å›¾çŽ‹,78f1ae2136e2125582220d9a4d77a3fdaa9f5e2e
Mathias Svensson,Multi Commander,630a71dc6fff81024b51c492e34992182a304706
NTeWORKS,PicPick,59ebc2a6abd2fd15eeb7a2c3d7e48cb7397d2056
Axantum Software AB,AxCrypt,518cc58561eb1ed1111b56cab39c8b4caf298a32
HTTPie,HTTPie,2e20048524ab4f9fff49b7f0376b12bc03300bd9
Oracle Corporation,Java(TM) Platform SE 8 U202,f4e09353d70c7edc2a46376c29c9f131534902a0
Code Sector Inc.,TeraCopy,511b593233722aa8b185d2efb14fa1c0ed1e8aa6
Postman,Postman,f5917a74a8a266e897104b7011b1e97131ad2942
NCH Software,WavePad,ebe6ee1fc2ae2bedbd37563902db601165f25572
Sophos B.V.,HitmanPro,7efb99475e37a3aa40465c15af14452925e5225f
 ,äºŒåˆ€æµå®›åå°åˆ·,fd42804b2f2668449ddf57ae7d3aa2c6ea1195b3
TechSmith Corporation,Snagit,ffc05b12e14fdd077166e9280eac4ca47f4888fa
IDRIX,VeraCrypt,fe7e018808cf85e7e04754500f18c440bc8a2724
Movavi ,Movavi Video Converter,0d11f15005bdd10de3a7ee1bebb868d2e1b6efbc
Code Sector,TeraCopy,dc16cc243b873963a8897225032b4a1096d9e8d7
Electronic Arts,Origin,a9f245b54ef78333483a105615a02fa0f0efc16f
Malwarebytes,AdwCleaner,7463365265141da80b59f1e539f5aa1d4b0bf2e5
BMD Systemhaus GmbH,BMDNTCS,fe9f9b55e332344b798e4043c23fc98afdfcd274
Skymatic GmbH,Cryptomator,e90dc120e57504b37addfbcaac2e510657e4752b
Swiss Academic Software,Citavi,b901a115c2ac8c6d5281a052bfa86afd6b7bcbaa
Mozilla Corporation,Tor Browser,e66b9b73b916273397fb7c248bf2f77ed3694bfc
Foxit Corporation,Foxit Reader,d2361feb183a2c36b30c65663db7a419df8e5a20
Monitoring Client,BitLocker,d1da0d23083ecf6018bae998c104fa9ba573bcce
AgileBits Inc.,1Password,a5f45f672ad421ab1bfa0d14813b58fae5dbd054
FastStone Soft,FastStone Capture,ca09b8f8e8f5110b750f3853d2cf03a526098434
LastPass US LP.,LastPass,e84d2632d81f81f6f3911db2f118501df419f420
"VanDyke Software, Inc.",SecureCRT,fd530c1a125bbdea223c99b9682e881270271995
GOG.com,GOG Galaxy,e6af7508cec6c0dd951db34faca58fb84471f3ea
"UltraEdit, Inc.",UltraEdit,ef58ccc49663887433ced5554466a9e5c3280a1d
GOM & Company,GOM Player,39e3659d0c4495d3e38e958e6a8020405f71cf90
Dominik Reichl,KeePass,ed1a56b9d794c2b695bf5d587fdf6cdb121a56fa
Oracle Corporation,Java(TM) Platform SE 7 U79,e77eb68c3d199a6d15c44d784e9ed06c60ac196b
AM Crypto,VeraCrypt,8e61431a87d3121d519a9157c1b712a4778dad89
"AgileBits, Inc.",1Password,c30e231003e4421b6481938959d2faaefee508dd
GP Software,Directory Opus,ddbfe6f6855192a8631459d3cc8f58e09f8bcc25
"Zhuhai Kingsoft Office Software Co.,Ltd",WPS Office,ff04e66fb45fc47603472104ffa7b7180619ed47
ShareX Team,ShareX,bb5fcea481dee7f21cbcef376b1f8c4d8386c19b
Geek Uninstaller,Geek-Uninstaller,515df2a9fb35beef25d070b688d692646f0a1c8f
Oracle and/or its affiliates,Oracle VM VirtualBox,fd44e26235d919932d30a10acea01e3d3b0de48c
"Epic Games, Inc.",Unreal Engine,fc7593973995945953c56105f42d9313b4179890
WiseCleaner.com,Wise Disk Cleaner,36e318fae991e4ba622ea1f81ca9f4acdef826ee
Gen Digital Inc.,CCleaner,ff855d6ffc71f6b2156484743c7fd90251500da5
Audacity Team,Audacity,d1f5013ae1c8295d116f7ddd44d2507328b19b31
Ammyy LLC,Ammyy Admin,5d7cb1a2ca7db04edf23dd3ed41125c8c867b0ad
Termius Corporation,Termius,f73f59eb53cbd53c3777a084bbe7d052e5f7c30b
Sogou.com,æœç‹—è¾"å…¥æ³•,ffa3bb9c687a47c016cdaa68f4695b2926136ba2
Sogou,QQæ‹¼éŸ³è¾"å…¥æ³• å‰ªè´´æ¿,fcf5ff698d5a11bc587017a996f1268383096693
Malwarebytes,Malwarebytes,f4ce66f16fee53215531d692ffb72101740690b5
Monitoring Client,OneDrive,45bca01e0f2cdb3597eaa331b8885f17d791de90
voidtools,Everything,fd3fe99212ac32f070243a67878201aaf1fd9d4b
 Foxit Software Inc,Foxit Reader,c04bf6987d65eaba31b0cb15b5ebe3a666a5606d
HandBrake Team,HandBrake,9fe29cdb1b783dee8bb2ba64789e821253577d27
"Riot Games, Inc.",Riot Client,0083c73f5fdaf2361d9c62bd7d796b749086487e
Martin Prikryl,WinSCP,feca2ab0bd116a0e909906eeea47aeb66a4ca845
"GitHub, Inc.",Atom,fa77127cc358d50aa4401135a992edcda22e81fa
Aagon GmbH,Aagon Client Management Platform,ffec53e130dab52487f9bcf7ab75cd8e70762e61
Skype Technologies,Skype,ff20ff07275c6a1c0ea3ebd371786b900435e183
Piriform Software Ltd,CCleaner,fb8a5483428b234ec93b188576302e08ebd01c26
BleachBit,BleachBit,f2a5012b7d9e5877505018c9e6e29c8caebc14dc
IObit,IObit Uninstaller,de4f56af09416aec8a0963db09213152dc7c029d
"Dropbox, Inc.",Dropbox,da6fb067caa52f780bfe9e7aaee6ca5f7086fe26
OriginLab Corporation,Origin,f4d8991f01dbdc40b27cb86d505ee10c85a9ba53
æ ªå¼ä¼šç¤¾ãƒ‡ã‚£ãƒ¼ãƒ»ã‚ªãƒ¼ãƒ»ã‚¨ã‚¹,ss1DevWMI,f7da56e56533f3466771adff9bd379e372a7dbd8
Tencent,è…¾è®¯ç"µè„'ç®¡å®¶,f1e093a54691faa09849db628c0a988a8eef84be
360.cn,360å®‰å…¨å«å£«,f47dc240f012bc9233950a66fe6664870dabfcc3
Uniface B.V.,Uniface,f9630f3717f1920281693082a88edbf3ad7e4cc1
Sofiane Fares | FranÃ§ois Bridonneau | A2C MatÃ©riaux,A2C - VÃ©rif,ff193255e2018e9366eec18e61d88ffa4bd05699
Alexander Roshal,WinRAR,fdc3009ea9727d87224a53c19046d1d6c8d70884
Mobatek,MobaXterm,f5ca50ee8bc9d01760c7d0d4fc0c814cbbf26bc9
Ubisoft,Ubisoft Connect,edd8c6d66d582fc62bd3c836e21ac016120e8b73
"IDM Computer Solutions, Inc.",UltraEdit,d918b4db936ca3e41f93d874e5ce0dc77baedd18
360.cn,360åŽ‹ç¼©,f660193cfc64012c323736b20ab43156140d412f
Zotero,Zotero,d695cf1b3949c674328ff836a03c1dc29ff6e582
Bandisoft.com,Bandizip,d330d453f18d86dcfa5ef7fba0c5c9f266477c5a
GlavSoft LLC.,TightVNC,fceb4c7708dd34dfa72a76b302782891fde4bdd3
Discord Inc.,Discord,e674f0509c998b170acd80017ea63a8fd2476b13
TeamViewer GmbH,TeamViewer,fe341152fb636c54487ea3807e11b5ad79221515
dotPDN LLC,Paint.NET,ed41bc52f274b77f6f121a80a3dfb3db106fc8e9
Oracle Corporation,Oracle VM VirtualBox,daee49684142f1cd9a6d4a5469ec0cba26a490bf
OBS,OBS Studio,f0e910b6d5da4a2601e202de95c25517be3f271d
SOURCENEXT CORPORATION,ç­†çŽ‹,b2709fba065e1366ce570e4d80ae54fbce4c29ad
Nanosystems S.r.l.,Supremo,058c2fa8408fbb80639ee224556a886fea4ebb2e
NGWIN,PicPick,fdc5ea3c3e8f2f43130330e85587d3a359106f8b
UltraVNC,UltraVNC,fed36ba4336e4ac726bcabc0148104dd739b05c9
Skillbrains,Lightshot,fa7b69793454131a5b21b32867533305651e2dd4
Corporation for Digital Scholarship,Zotero,fb1c15ac6e999d8ca65e832e3ecb58a763d69014
æ ªå¼ä¼šç¤¾ ãƒ•ã‚©ãƒ¯ãƒ¼ãƒ‰,ã‚²ãƒ¼ãƒˆã‚¦ã‚§ã‚¤ãƒ­ã‚°ç…§ä¼š,f667f777ef42f78bdc397a5ceae806a5f1d9779f
Oracle Corporation,Java(TM) Platform SE 17.0.1,a11cd33a675d228c9cf6f1fb3340abc38d35067c
Kingsoft Corp. Ltd.,WPS Office,64dbe4c105a9780af5a313c75efe9ba2cd9968c1
Movavi,Movavi Video Converter,910b5ff01e62f8a8862e7b1d274865d1a1a459a8
Xrev,Transmit,26f3af72b2f03f674b7680c091c3ddcbfb24c758
"""

# Parse and enrich - FIXED VERSION
output_path = Path("src/assessor/resolver/products_db.csv")
with open(output_path, "w", encoding="utf-8", newline="") as f:
    writer = csv.writer(f)
    writer.writerow(["company_name", "product_name", "sha1", "category", "homepage"])
    
    # ✅ Use csv.reader to handle quoted fields correctly
    reader = csv.reader(StringIO(source_csv))
    next(reader)  # Skip header
    
    for row in reader:
        if len(row) < 3:
            continue
        
        company = row[0].strip()
        product = row[1].strip()
        sha1 = row[2].strip()
        
        category = infer_category(product, company)
        homepage = infer_homepage(company, product)
        
        writer.writerow([company, product, sha1, category, homepage])

print(f"✅ Imported full dataset to {output_path}")
print(f"Run: poetry run assessor assess 'KeePass' --offline")